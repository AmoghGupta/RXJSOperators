import {interval, timer, fromEvent, Observable, noop } from "rxjs";


export function createHttpObservable(url:string){
  // creating a custom observable
  return Observable.create(
    observer => {

      // to cancel a request
      //(cancelleble http observable)
      const controller = new AbortController();
      const signal = controller.signal;

      fetch(url, {signal}).then(
        response=>{

          if(response.ok){
            return response.json();
          }else{
            observer.error('Request failed with status code: '+response.status);
          }


        }
      ).then(
        (jsonresp)=>{
          // next is the method that is used to emit values in an observable
          observer.next(jsonresp);

          // observable completed
          observer.complete();
        }
      ).catch(
        (err)=>{
          observer.error(err);
        }
      )

      // enables us to unsubscribe/cance/abort the ongoing request
      //(cancelleble http observable)
      return ()=> controller.abort();
    }
  );
}
